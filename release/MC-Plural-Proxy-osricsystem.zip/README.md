# MC Plural Proxy
A simple Minecraft datapack for proxying messages

![Minecraft Version](https://img.shields.io/badge/Minecraft-1.16.5-80ba42?style=for-the-badge) ![License](https://img.shields.io/github/license/OsricSystem/mc-plural-proxy?style=for-the-badge) ![Last Commit](https://img.shields.io/github/last-commit/OsricSystem/mc-plural-proxy?style=for-the-badge)

[![forthebadge](https://forthebadge.com/images/badges/ctrl-c-ctrl-v.svg)](https://forthebadge.com) [![forthebadge](https://forthebadge.com/images/badges/built-with-love.svg)](https://forthebadge.com)

## Setting up a system
To get started on creating a system, please check the [Wiki](https://github.com/DBTDerpbox/MC-Plural-Proxy/wiki)

### Notices

MC Plural Proxy is currently designed for [Minecraft Java Edition 1.16.5](https://www.minecraft.net/en-us/article/minecraft-java-edition-1-16-5)
